本地包版本:20241126-1 (2025-1-1修正发布)
作者:道长
QQ群:824179147
PC:zyplayer 与 Mobile:easybox 通用
easybox 支持网盘源播放，如阿里土豆。zyplayer暂不支持

zyplayer导入教程:
1.drpy_dzlive整个文件夹丢到zy服务目录的根目录，注意不是安装目录(写源工具-运行-服务)
2.zy设置数据导入hipy源输入下面的地址:
http://127.0.0.1:9978/api/v1/file/drpy_dzlive/

注意: 推荐使用 zyplayer3.3.5 0519-1 及以上版本

easybox导入教程:
1.在手机上创建 easybox目录,将此本地包解压到easybox目录内。本地包index.js目标路径: /sdcard/easybox/drpy_dzlive/index.js
2.新增订阅添加以下内容: file://easybox/drpy_dzlive/index.json
3.打开首页源:网盘及弹幕配置 阿里云盘扫码登录，获取token成功.然后点击Alist提取openToken。成功了就可以使用阿里土豆等源播放了

其他说明:
index.js仅限zyplayer配置使用
index.json可以给手机壳子easybox使用本地包

更新日志:
1. 更新本地包里的全部drpy_libs、升级drpy版本以支持更多属性，如搜索过验证自定义标识、禁止搜索翻页
2. 腾讯搜索修复
3. 其他源微调、如央视大全播放问题
4. 腾讯源搜索兼容壳子
5.更新龙头去广告算法